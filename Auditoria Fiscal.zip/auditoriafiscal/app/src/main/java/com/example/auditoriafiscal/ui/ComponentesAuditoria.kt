package com.example.auditoriafiscal.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.example.auditoriafiscal.R
import com.example.auditoriafiscal.model.AuditoriaRepository
import com.example.auditoriafiscal.model.ItemAuditoria
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class DateVisualTransformation : VisualTransformation {
    override fun filter(text: AnnotatedString): TransformedText {
        val trimmed = text.text.take(8)
        var out = ""
        for (i in trimmed.indices) {
            out += trimmed[i]
            if (i == 1 || i == 3) out += "/"
        }
        val offsetMapping = object : OffsetMapping {
            override fun originalToTransformed(offset: Int): Int {
                if (offset <= 1) return offset
                if (offset <= 3) return offset + 1
                if (offset <= 8) return offset + 2
                return 10
            }
            override fun transformedToOriginal(offset: Int): Int {
                if (offset <= 2) return offset
                if (offset <= 5) return offset - 1
                if (offset <= 10) return offset - 2
                return 8
            }
        }
        return TransformedText(AnnotatedString(out), offsetMapping)
    }
}

fun prazoEhValido(prazo: String): Boolean {
    if (prazo.length != 10) return false
    return try {
        val formato = SimpleDateFormat("dd/MM/yyyy", Locale("pt", "BR")).apply { isLenient = false }
        val data = formato.parse(prazo) ?: return false
        val hoje = formato.parse(formato.format(Date())) ?: return false
        !data.before(hoje)
    } catch (e: Exception) {
        false
    }
}

@Composable
fun MiniaturaEvidencia(caminho: String, timestamp: String?) {
    val bitmap = remember(caminho) { AuditoriaRepository.carregarMiniatura(caminho, 8)?.asImageBitmap() }
    Column(modifier = Modifier.padding(top = 8.dp)) {
        if (bitmap != null) {
            Image(
                bitmap = bitmap,
                contentDescription = "Foto de evidência",
                modifier = Modifier.size(100.dp)
            )
        } else {
            Text(text = stringResource(R.string.foto_anexada), style = MaterialTheme.typography.labelSmall)
        }
        if (timestamp != null) {
            Text(
                text = "Capturada em: $timestamp",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.outline
            )
        }
    }
}

@Composable
fun CardItemSomenteLeitura(item: ItemAuditoria) {
    Card(modifier = Modifier.fillMaxWidth(), elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(
                text = "[${item.codigoPapelTrabalho}] ${item.categoria} - ${item.obterOrgaoFiscalizador()}",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = item.descricao, fontWeight = FontWeight.Bold)
            Text(
                text = "Base Legal: ${item.obterBaseLegalPadrao()}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.outline
            )
            Spacer(modifier = Modifier.height(4.dp))

            val nc = item.naoConformidade
            if (item.status == "Não Conforme" && nc != null) {
                Text(text = stringResource(R.string.status_nao_conforme, nc.nivelSeveridade), color = MaterialTheme.colorScheme.error)
                Text(text = "Critério violado: ${nc.criterioNormativo}", style = MaterialTheme.typography.bodySmall)
                Text(text = stringResource(R.string.status_apontamento, nc.obterStatus()), style = MaterialTheme.typography.bodySmall)
                Text(text = stringResource(R.string.prazo_nao_conformidade, nc.prazoResolucao), style = MaterialTheme.typography.bodySmall)
                Text(text = stringResource(R.string.obs_nao_conformidade, nc.observacao), style = MaterialTheme.typography.bodySmall)
            } else {
                Text(text = "Status: ${item.status}", color = MaterialTheme.colorScheme.secondary)
            }
            item.caminhoFoto?.let { MiniaturaEvidencia(it, item.timestampFoto) }
        }
    }
}

@Composable
fun CardItemAuditoria(
    item: ItemAuditoria,
    onConformeClick: () -> Unit,
    onEvidenciaClick: () -> Unit,
    onNaoConformeClick: () -> Unit,
    onRemoverEvidenciaClick: () -> Unit
) {
    Card(modifier = Modifier.fillMaxWidth(), elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "${item.codigoPapelTrabalho} - ${item.obterBaseLegalPadrao()}",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = item.descricao, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Bold)

            val nc = item.naoConformidade
            if (item.status == "Não Conforme" && nc != null) {
                Text(text = stringResource(R.string.status_nao_conforme, nc.nivelSeveridade), color = MaterialTheme.colorScheme.error)
                Text(text = "Norma: ${nc.criterioNormativo}", style = MaterialTheme.typography.bodySmall)
                Text(text = stringResource(R.string.prazo_nao_conformidade, nc.prazoResolucao), style = MaterialTheme.typography.bodySmall)
            } else if (item.status == "Conforme") {
                Text(text = stringResource(R.string.status_conforme), color = MaterialTheme.colorScheme.primary)
            } else {
                Text(text = stringResource(R.string.status_pendente), color = MaterialTheme.colorScheme.secondary)
            }

            item.caminhoFoto?.let { caminho ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    MiniaturaEvidencia(caminho, item.timestampFoto)
                    Spacer(modifier = Modifier.width(16.dp))
                    TextButton(onClick = onRemoverEvidenciaClick) {
                        Text("Excluir Foto", color = MaterialTheme.colorScheme.error)
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Button(onClick = onConformeClick, colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)) {
                    Text(stringResource(R.string.btn_ok))
                }
                Button(onClick = onEvidenciaClick, colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)) {
                    Text(stringResource(R.string.btn_foto))
                }
                Button(onClick = onNaoConformeClick, colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)) {
                    Text(stringResource(R.string.btn_falha))
                }
            }
        }
    }
}

@Composable
fun DialogNaoConformidade(
    item: ItemAuditoria,
    onDismiss: () -> Unit,
    onLerFotoIA: ((String) -> Unit) -> Unit = {},
    onSave: (severidade: String, criterio: String, observacao: String, prazo: String) -> Unit
) {
    var severidade by remember { mutableStateOf(item.sugerirSeveridadePadrao()) }
    var criterioNormativo by remember { mutableStateOf(item.obterBaseLegalPadrao()) }
    var observacao by remember { mutableStateOf("") }
    var prazoRaw by remember { mutableStateOf("") }
    var lendoComIA by remember { mutableStateOf(false) }

    fun validarRaw(raw: String): Boolean {
        if (raw.length != 8) return false
        val formatado = "${raw.substring(0, 2)}/${raw.substring(2, 4)}/${raw.substring(4, 8)}"
        return prazoEhValido(formatado)
    }

    val prazoValido = validarRaw(prazoRaw)
    val podeSalvar = severidade.isNotEmpty() && criterioNormativo.isNotBlank() && observacao.isNotBlank() && prazoValido

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.titulo_nao_conformidade)) },
        text = {
            Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                Text(
                    text = "${item.codigoPapelTrabalho} - ${item.descricao}",
                    fontWeight = FontWeight.Medium
                )
                Spacer(modifier = Modifier.height(12.dp))

                // Botão de Leitura via Google ML Kit (aparece quando o item tem foto)
                if (item.caminhoFoto != null) {
                    FilledTonalButton(
                        onClick = {
                            lendoComIA = true
                            onLerFotoIA { textoExtraido ->
                                observacao = textoExtraido
                                lendoComIA = false
                            }
                        },
                        enabled = !lendoComIA,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(if (lendoComIA) "🔍 Lendo documento fiscal..." else "✨ Ler Foto com IA (ML Kit)")
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                } else {
                    Text(
                        text = "💡 Dica: Tire uma 'Foto' antes de abrir a falha para preencher a observação via IA.",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.outline
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                }

                OutlinedTextField(
                    value = criterioNormativo,
                    onValueChange = { criterioNormativo = it },
                    label = { Text("Critério Normativo / Lei (ISO 19011)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = observacao,
                    onValueChange = { observacao = it },
                    label = { Text(stringResource(R.string.label_observacao)) },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = prazoRaw,
                    onValueChange = { valorDigitado ->
                        val soNumeros = valorDigitado.filter { it.isDigit() }
                        if (soNumeros.length <= 8) prazoRaw = soNumeros
                    },
                    label = { Text(stringResource(R.string.label_prazo)) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    visualTransformation = DateVisualTransformation(),
                    singleLine = true,
                    isError = prazoRaw.length == 8 && !prazoValido,
                    modifier = Modifier.fillMaxWidth()
                )
                if (prazoRaw.length == 8 && !prazoValido) {
                    Text(stringResource(R.string.prazo_invalido), color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }

                Spacer(modifier = Modifier.height(16.dp))
                Text(stringResource(R.string.selecione_severidade))
                Spacer(modifier = Modifier.height(8.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    listOf(
                        stringResource(R.string.severidade_baixa),
                        stringResource(R.string.severidade_media),
                        stringResource(R.string.severidade_alta)
                    ).forEach { nivel ->
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            RadioButton(selected = severidade == nivel, onClick = { severidade = nivel })
                            Text(nivel, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val prazoFormatado = "${prazoRaw.substring(0, 2)}/${prazoRaw.substring(2, 4)}/${prazoRaw.substring(4, 8)}"
                    onSave(severidade, criterioNormativo, observacao, prazoFormatado)
                },
                enabled = podeSalvar
            ) {
                Text(stringResource(R.string.btn_salvar))
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.btn_cancelar)) } }
    )
}