package com.example.auditoriafiscal.model

import kotlinx.serialization.Serializable
import kotlinx.serialization.Transient
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Estados possíveis de um apontamento (US04). */
object StatusApontamento {
    const val PENDENTE = "Pendente"
    const val EM_ANDAMENTO = "Em Andamento"
    const val RESOLVIDO = "Resolvido"
    val todos = listOf(PENDENTE, EM_ANDAMENTO, RESOLVIDO)
}

/**
 * CABEÇALHO DO PLANO DE AUDITORIA (Exigência ABNT NBR ISO 19011 - Seção 6.3).
 * Identifica formalmente a entidade auditada e o período fiscal antes do checklist.
 */
@Serializable
data class PlanoAuditoria(
    val protocolo: String = "PT-${System.currentTimeMillis().toString().takeLast(5)}",
    var razaoSocial: String = "Empresa Modelo LTDA",
    var cnpj: String = "12.345.678/0001-90",
    var competenciaFiscal: String = "11/2026",
    var responsavelAuditado: String = "Gerente de Controladoria",
    val dataAbertura: String = SimpleDateFormat("dd/MM/yyyy", Locale("pt", "BR")).format(Date())
)

/**
 * REGISTRO DE NÃO CONFORMIDADE (Tríade ISO 19011 - Seção 6.4.7).
 * Reúne: Critério Normativo violado + Observação (Constatação) + Prazo + Status.
 */
@Serializable
data class NaoConformidade(
    val idItem: Int,
    var nivelSeveridade: String = "",
    var criterioNormativo: String = "", // Lei ou norma infringida (ISO 19011)
    var observacao: String = "",        // Constatação do auditor
    var prazoResolucao: String = "",
    var status: String = StatusApontamento.PENDENTE,
    @Transient val evidencias: MutableList<ByteArray> = mutableListOf()
) {
    fun adicionarEvidencia(foto: ByteArray) {
        evidencias.add(foto)
    }

    fun obterStatus(): String = status
}

/**
 * CLASSE MÃE (Polimorfismo / Herança):
 * Define apenas os atributos universais do Papel de Trabalho (CFC NBC TA 230).
 * As funções específicas são divididas nas classes filhas para evitar uma classe gigante.
 */
@Serializable
sealed class ItemAuditoria {
    abstract val id: Int
    abstract val codigoPapelTrabalho: String
    abstract val categoria: String
    abstract val descricao: String
    abstract var status: String
    abstract var naoConformidade: NaoConformidade?
    abstract var caminhoFoto: String?
    abstract var timestampFoto: String? // Rastreabilidade de evidência (NBC TA 500)

    val temEvidencia: Boolean get() = caminhoFoto != null

    // Comportamentos delegados para cada classe filha:
    abstract fun obterBaseLegalPadrao(): String
    abstract fun obterOrgaoFiscalizador(): String
    abstract fun sugerirSeveridadePadrao(): String
    abstract fun copiarComStatus(
        novoStatus: String = this.status,
        novaNC: NaoConformidade? = this.naoConformidade,
        novaFoto: String? = this.caminhoFoto,
        novoTimestamp: String? = this.timestampFoto
    ): ItemAuditoria
}

/** CLASSE FILHA 1: Regras exclusivas de Tributos Federais (Receita Federal) */
@Serializable
data class ItemTributoFederal(
    override val id: Int,
    override val codigoPapelTrabalho: String,
    override val descricao: String,
    val codigoDarf: String,
    override var status: String = "Pendente",
    override var naoConformidade: NaoConformidade? = null,
    override var caminhoFoto: String? = null,
    override var timestampFoto: String? = null
) : ItemAuditoria() {

    override val categoria: String = "Tributos Federais"

    override fun obterBaseLegalPadrao(): String =
        "Lei nº 9.430/96 e CTN Art. 195 (Cód. Receita DARF: $codigoDarf)"

    override fun obterOrgaoFiscalizador(): String = "Receita Federal do Brasil (RFB / SPED)"

    override fun sugerirSeveridadePadrao(): String = "Alta"

    override fun copiarComStatus(
        novoStatus: String,
        novaNC: NaoConformidade?,
        novaFoto: String?,
        novoTimestamp: String?
    ): ItemAuditoria = copy(
        status = novoStatus,
        naoConformidade = novaNC,
        caminhoFoto = novaFoto,
        timestampFoto = novoTimestamp
    )
}

/** CLASSE FILHA 2: Regras exclusivas de Tributos Estaduais (SEFAZ / ICMS) */
@Serializable
data class ItemTributoEstadual(
    override val id: Int,
    override val codigoPapelTrabalho: String,
    override val descricao: String,
    val modeloDocumentoFiscal: String, // Ex: "NF-e Modelo 55" ou "GNRE"
    override var status: String = "Pendente",
    override var naoConformidade: NaoConformidade? = null,
    override var caminhoFoto: String? = null,
    override var timestampFoto: String? = null
) : ItemAuditoria() {

    override val categoria: String = "Tributos Estaduais"

    override fun obterBaseLegalPadrao(): String =
        "Lei Complementar nº 87/96 (Lei Kandir) - Doc: $modeloDocumentoFiscal"

    override fun obterOrgaoFiscalizador(): String = "Secretaria da Fazenda Estadual (SEFAZ)"

    override fun sugerirSeveridadePadrao(): String = "Média"

    override fun copiarComStatus(
        novoStatus: String,
        novaNC: NaoConformidade?,
        novaFoto: String?,
        novoTimestamp: String?
    ): ItemAuditoria = copy(
        status = novoStatus,
        naoConformidade = novaNC,
        caminhoFoto = novaFoto,
        timestampFoto = novoTimestamp
    )
}

/** CLASSE FILHA 3: Regras exclusivas Trabalhistas (CLT / eSocial / NRs) */
@Serializable
data class ItemTrabalhista(
    override val id: Int,
    override val codigoPapelTrabalho: String,
    override val descricao: String,
    val normaReferencia: String, // Ex: "Lei 8.036/90 (FGTS)" ou "NR-01"
    override var status: String = "Pendente",
    override var naoConformidade: NaoConformidade? = null,
    override var caminhoFoto: String? = null,
    override var timestampFoto: String? = null
) : ItemAuditoria() {

    override val categoria: String = "Trabalhista"

    override fun obterBaseLegalPadrao(): String =
        "CLT / eSocial - Diretriz: $normaReferencia"

    override fun obterOrgaoFiscalizador(): String = "Ministério do Trabalho e Emprego (MTE)"

    override fun sugerirSeveridadePadrao(): String = "Alta"

    override fun copiarComStatus(
        novoStatus: String,
        novaNC: NaoConformidade?,
        novaFoto: String?,
        novoTimestamp: String?
    ): ItemAuditoria = copy(
        status = novoStatus,
        naoConformidade = novaNC,
        caminhoFoto = novaFoto,
        timestampFoto = novoTimestamp
    )
}

/**
 * HISTÓRICO: Representa uma auditoria finalizada e arquivada (Jornada do Auditor).
 * Movido para o escopo global (fora de qualquer classe filha).
 */
@Serializable
data class AuditoriaConcluida(
    val dataFechamento: String,
    val plano: PlanoAuditoria,
    val itens: List<ItemAuditoria>
)