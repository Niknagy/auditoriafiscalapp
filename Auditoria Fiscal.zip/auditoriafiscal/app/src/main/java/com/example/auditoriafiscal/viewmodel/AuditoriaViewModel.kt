package com.example.auditoriafiscal.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.auditoriafiscal.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class AuditoriaUiState(
    val plano: PlanoAuditoria = PlanoAuditoria(),
    val itens: List<ItemAuditoria> = emptyList(),
    val historico: List<AuditoriaConcluida> = emptyList(), // <-- NOVO
    val sincronizandoNuvem: Boolean = false,
    val statusNuvem: String = "Apenas Local (Offline-First)"
    ) {
    val pendentes: Int get() = itens.count { it.status == "Pendente" }
    val statusSessao: String get() = when {
        pendentes == itens.size -> "Não Iniciada"
        pendentes == 0 -> "Concluída"
        else -> "Em Andamento"
    }

    val apontamentosAbertos: Int get() = itens.count {
        it.naoConformidade != null && it.naoConformidade!!.status != StatusApontamento.RESOLVIDO
    }
}

class AuditoriaViewModel(private val repository: AuditoriaRepository) : ViewModel() {

    private val _uiState = MutableStateFlow(
        AuditoriaUiState(
            plano = repository.carregarPlano(),
            itens = repository.carregarItens(),
            historico = repository.carregarHistorico() // <-- NOVO
        )
    )
    val uiState: StateFlow<AuditoriaUiState> = _uiState.asStateFlow()

    fun atualizarPlano(razaoSocial: String, cnpj: String, competencia: String, responsavel: String) {
        val planoAtualizado = _uiState.value.plano.copy(
            razaoSocial = razaoSocial,
            cnpj = cnpj,
            competenciaFiscal = competencia,
            responsavelAuditado = responsavel
        )
        repository.salvarPlano(planoAtualizado)
        _uiState.update { it.copy(plano = planoAtualizado) }
    }

    fun marcarConforme(idItem: Int) {
        val item = _uiState.value.itens.firstOrNull { it.id == idItem } ?: return
        substituirItem(item.copiarComStatus(novoStatus = "Conforme", novaNC = null))
    }

    fun registrarNaoConformidade(
        idItem: Int,
        severidade: String,
        criterioNormativo: String,
        observacao: String,
        prazo: String
    ) {
        val item = _uiState.value.itens.firstOrNull { it.id == idItem } ?: return
        val novaNC = NaoConformidade(
            idItem = idItem,
            nivelSeveridade = severidade,
            criterioNormativo = criterioNormativo,
            observacao = observacao,
            prazoResolucao = prazo
        )
        substituirItem(item.copiarComStatus(novoStatus = "Não Conforme", novaNC = novaNC))
    }

    fun atualizarStatusApontamento(idItem: Int, novoStatus: String) {
        val item = _uiState.value.itens.firstOrNull { it.id == idItem } ?: return
        val nc = item.naoConformidade ?: return
        substituirItem(item.copiarComStatus(novaNC = nc.copy(status = novoStatus)))
    }

    fun novoArquivoFoto(idItem: Int): File = repository.novoArquivoFoto(idItem)

    fun descartarArquivo(caminho: String) = repository.excluirFoto(caminho)

    fun registrarFoto(idItem: Int, caminho: String) {
        val item = _uiState.value.itens.firstOrNull { it.id == idItem } ?: return
        if (item.caminhoFoto != null && item.caminhoFoto != caminho) {
            repository.excluirFoto(item.caminhoFoto)
        }
        val agora = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("pt", "BR")).format(Date())
        item.naoConformidade?.adicionarEvidencia(AuditoriaRepository.miniaturaEmBytes(caminho))
        substituirItem(item.copiarComStatus(novaFoto = caminho, novoTimestamp = agora))
    }

    fun removerFoto(idItem: Int) {
        val item = _uiState.value.itens.firstOrNull { it.id == idItem } ?: return
        repository.excluirFoto(item.caminhoFoto)
        item.naoConformidade?.evidencias?.clear()
        substituirItem(item.copiarComStatus(novaFoto = null, novoTimestamp = null))
    }

    fun extrairDadosDaFotoComIA(caminhoFoto: String, onTextoExtraido: (String) -> Unit) {
        repository.analisarFotoComIA(caminhoFoto, onTextoExtraido)
    }

    fun sincronizarComNuvem() {
        viewModelScope.launch(Dispatchers.IO) {
            _uiState.update { it.copy(sincronizandoNuvem = true, statusNuvem = "Sincronizando com Cloudflare...") }

            val resultado = repository.sincronizarComCloudflare()

            _uiState.value.itens.filter { it.caminhoFoto != null }.forEach { item ->
                repository.enviarFotoParaCloudflareR2(item.id, item.caminhoFoto!!)
            }

            val mensagemFinal = resultado.fold(
                onSuccess = { "OK: $it" },
                onFailure = { "Salvo localmente (Cloudflare offline ou URL de teste)" }
            )

            _uiState.update { it.copy(sincronizandoNuvem = false, statusNuvem = mensagemFinal) }
        }
    }

    fun limparAuditoria() {
        _uiState.value.itens.forEach { repository.excluirFoto(it.caminhoFoto) }
        val novoPlano = PlanoAuditoria()
        val itensIniciais = repository.itensIniciaisPolimorficos()
        repository.salvarPlano(novoPlano)
        repository.salvarItens(itensIniciais)
        _uiState.update { AuditoriaUiState(plano = novoPlano, itens = itensIniciais) }
    }

    private fun substituirItem(itemAtualizado: ItemAuditoria) {
        val novaLista = _uiState.value.itens.map {
            if (it.id == itemAtualizado.id) itemAtualizado else it
        }
        repository.salvarItens(novaLista)
        _uiState.update { it.copy(itens = novaLista) }
    }

    fun fecharEArquivarAuditoria() {
        val estadoAtual = _uiState.value
        val dataAgora = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("pt", "BR")).format(Date())

        // 1. Empacota o trabalho atual
        val auditoriaFinalizada = AuditoriaConcluida(
            dataFechamento = dataAgora,
            plano = estadoAtual.plano,
            itens = estadoAtual.itens
        )

        // 2. Adiciona na lista do histórico e salva no SharedPreferences
        val novoHistorico = estadoAtual.historico + auditoriaFinalizada
        repository.salvarHistorico(novoHistorico)

        // 3. Atualiza a UI e zera a sessão ativa para a próxima fiscalização
        _uiState.update { it.copy(historico = novoHistorico) }
        limparAuditoria()
    }

}

class AuditoriaViewModelFactory(private val context: Context) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return AuditoriaViewModel(AuditoriaRepository(context.applicationContext)) as T
    }
}