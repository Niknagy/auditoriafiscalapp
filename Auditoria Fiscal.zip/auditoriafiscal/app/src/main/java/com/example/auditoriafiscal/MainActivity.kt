package com.example.auditoriafiscal

import android.os.Bundle
import android.widget.Toast
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.toRoute
import com.example.auditoriafiscal.ui.*
import com.example.auditoriafiscal.viewmodel.AuditoriaViewModel
import com.example.auditoriafiscal.viewmodel.AuditoriaViewModelFactory

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    Box(modifier = Modifier.fillMaxSize().safeDrawingPadding()) {
                        AppComSegurancaBiometrica()
                    }
                }
            }
        }
    }
}

@Composable
fun AppComSegurancaBiometrica() {
    var autenticado by remember { mutableStateOf(false) }
    val context = LocalContext.current as AppCompatActivity

    fun dispararBiometria() {
        val executor = ContextCompat.getMainExecutor(context)
        val biometricPrompt = BiometricPrompt(context, executor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    super.onAuthenticationSucceeded(result)
                    autenticado = true
                }
                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    super.onAuthenticationError(errorCode, errString)
                    // Se o usuário cancelar, apenas avisa na tela
                    if (errorCode != BiometricPrompt.ERROR_NEGATIVE_BUTTON && errorCode != BiometricPrompt.ERROR_USER_CANCELED) {
                        Toast.makeText(context, "Erro biométrico: $errString", Toast.LENGTH_SHORT).show()
                    }
                }
            })

        val promptInfo = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Autenticação do Auditor Fiscal")
            .setSubtitle("Confirme sua digital para acessar o sistema")
            .setNegativeButtonText("Cancelar")
            .build()

        biometricPrompt.authenticate(promptInfo)
    }

    // Dispara automaticamente assim que a tela monta
    LaunchedEffect(Unit) {
        dispararBiometria()
    }

    if (autenticado) {
        AppNavigation()
    } else {
        // Tela de bloqueio estilizada caso o usuário feche o pop-up da digital
        Box(
            modifier = Modifier.fillMaxSize().padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "Sistema Protegido",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "A autenticação biométrica é necessária para acessar os dados fiscais.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.outline
                )
                Spacer(modifier = Modifier.height(24.dp))
                Button(
                    onClick = { dispararBiometria() },
                    modifier = Modifier.fillMaxWidth().height(50.dp)
                ) {
                    Text("Tentar Novamente com Digital")
                }
            }
        }
    }
}

@Composable
fun AppNavigation() {
    val navController = rememberNavController()
    val context = LocalContext.current
    val viewModel: AuditoriaViewModel = viewModel(factory = AuditoriaViewModelFactory(context))

    NavHost(navController = navController, startDestination = RotaHome) {
        composable<RotaHome> { TelaHome(navController, viewModel) }
        composable<RotaCategorias> { TelaCategorias(navController) }
        composable<RotaChecklist> {
            val rota = it.toRoute<RotaChecklist>()
            TelaChecklistAuditoria(navController, rota.categoria, viewModel)
        }
        composable<RotaResumo> {
            val rota = it.toRoute<RotaResumo>()
            TelaResumoAuditoria(navController, rota.categoria, viewModel)
        }
    }
}