package com.example.auditoriafiscal.model

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.json.Json
import java.io.ByteArrayOutputStream
import java.io.File
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

class AuditoriaRepository(private val context: Context) {
    private val prefs = context.getSharedPreferences("auditoria_db_v3", Context.MODE_PRIVATE)
    private val json = Json { ignoreUnknownKeys = true }
    private val listaSerializer = ListSerializer(ItemAuditoria.serializer())

    fun salvarPlano(plano: PlanoAuditoria) {
        val encoded = json.encodeToString(PlanoAuditoria.serializer(), plano)
        prefs.edit().putString(CHAVE_PLANO, encoded).apply()
    }

    fun carregarPlano(): PlanoAuditoria {
        val salvo = prefs.getString(CHAVE_PLANO, null) ?: return PlanoAuditoria()
        return try {
            json.decodeFromString(PlanoAuditoria.serializer(), salvo)
        } catch (e: Exception) {
            PlanoAuditoria()
        }

    }

    private val historicoSerializer = ListSerializer(AuditoriaConcluida.serializer())

    // CHAVE DE SEGURANÇA PARA O BANCO DE DADOS (API KEY)
    private val apiTokenAuditor = "SENHA_SECRETA_FATEC_2026"

    fun salvarHistorico(auditorias: List<AuditoriaConcluida>) {
        val encoded = json.encodeToString(historicoSerializer, auditorias)
        prefs.edit().putString("historico_v3", encoded).apply()
    }

    fun carregarHistorico(): List<AuditoriaConcluida> {
        val salvo = prefs.getString("historico_v3", null) ?: return emptyList()
        return try { json.decodeFromString(historicoSerializer, salvo) } catch (e: Exception) { emptyList() }
    }

    fun salvarItens(itens: List<ItemAuditoria>) {
        val encoded = json.encodeToString(listaSerializer, itens)
        prefs.edit().putString(CHAVE_ITENS, encoded).apply()
        // Ponto de extensão Cloud (Cloudflare Workers + D1 / Supabase):
        // sincronizarComNuvem(encoded)
    }

    fun carregarItens(): List<ItemAuditoria> {
        val salvo = prefs.getString(CHAVE_ITENS, null)
        if (salvo != null) {
            try {
                return json.decodeFromString(listaSerializer, salvo)
            } catch (e: Exception) {
                // Se mudar o schema, recarrega os itens iniciais das classes filhas
            }
        }
        return itensIniciaisPolimorficos()
    }

    fun novoArquivoFoto(idItem: Int): File {
        val pasta = File(context.filesDir, "evidencias").apply { mkdirs() }
        return File(pasta, "item_${idItem}_${System.currentTimeMillis()}.jpg").apply { createNewFile() }
    }

    fun excluirFoto(caminho: String?) {
        if (caminho != null) File(caminho).delete()
    }

    // =========================================================================
    // INTEGRAÇÃO CLOUDFLARE (WORKERS + D1 DATABASE + R2 STORAGE)
    // =========================================================================

    // Troque pela URL do seu Worker quando criar na sua conta Cloudflare:
    private val cloudflareWorkerUrl = "https://auditoria-api.falcaof22.workers.dev"

    /**
     * Envia o Plano de Auditoria e a lista polimórfica de Itens (JSON) para o Cloudflare D1.
     * Mantém a estratégia Offline-First: salva no aparelho antes e sincroniza em background.
     */
    fun sincronizarComCloudflare(): Result<String> = runCatching {
        val planoJson = prefs.getString(CHAVE_PLANO, null)
            ?: json.encodeToString(PlanoAuditoria.serializer(), carregarPlano())
        val itensJson = prefs.getString(CHAVE_ITENS, null)
            ?: json.encodeToString(listaSerializer, carregarItens())

        val historicoJson = prefs.getString("historico_v3", "[]")
        val payload = """{"plano":$planoJson,"itens":$itensJson,"historico":$historicoJson}"""

        val url = java.net.URL("$cloudflareWorkerUrl/api/sincronizar")

        val conn = (url.openConnection() as java.net.HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 8000
            readTimeout = 8000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("Authorization", "Bearer $apiTokenAuditor")
        }

        conn.outputStream.use { os ->
            os.write(payload.toByteArray(Charsets.UTF_8))
        }

        val codigoHttp = conn.responseCode
        if (codigoHttp in 200..299) {
            "Sincronizado com Cloudflare D1 (HTTP $codigoHttp)"
        } else {
            throw Exception("Erro no Worker: HTTP $codigoHttp")
        }
    }

    /**
     * Faz o upload do arquivo físico da foto (.jpg) para o bucket do Cloudflare R2.
     */
    fun enviarFotoParaCloudflareR2(idItem: Int, caminhoFoto: String): Result<String> = runCatching {
        val arquivo = File(caminhoFoto)
        if (!arquivo.exists()) throw Exception("Arquivo de foto não encontrado")

        val url = java.net.URL("$cloudflareWorkerUrl/api/evidencia/$idItem")
        val conn = (url.openConnection() as java.net.HttpURLConnection).apply {
            requestMethod = "PUT"
            connectTimeout = 10000
            doOutput = true
            setRequestProperty("Content-Type", "image/jpeg")
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("Authorization", "Bearer $apiTokenAuditor")
        }

        arquivo.inputStream().use { input ->
            conn.outputStream.use { output -> input.copyTo(output) }
        }

        val codigoHttp = conn.responseCode
        if (codigoHttp in 200..299) {
            "Evidência salva no Cloudflare R2"
        } else {
            throw Exception("Falha no upload R2: HTTP $codigoHttp")
        }

    }


    // =========================================================================
    // IA ON-DEVICE (GOOGLE ML KIT OCR - PRIVACY BY DESIGN / LGPD)
    // =========================================================================
    fun analisarFotoComIA(caminhoFoto: String, onResultado: (String) -> Unit) {
        val bitmap = carregarMiniatura(caminhoFoto, 2)
        if (bitmap == null) {
            onResultado("Nao foi possivel carregar a imagem para leitura.")
            return
        }

        val imagem = InputImage.fromBitmap(bitmap, 0)
        val reconhecedor = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

        reconhecedor.process(imagem)
            .addOnSuccessListener { visionText ->
                val textoBruto = visionText.text
                if (textoBruto.isBlank()) {
                    onResultado("Foto validada, mas nenhum texto legivel foi detectado.")
                    return@addOnSuccessListener
                }

                // 1. Extração cirúrgica de campos fiscais via Regex:
                val cnpj = Regex("""\d{2}\.\d{3}\.\d{3}/\d{4}-\d{2}""").find(textoBruto)?.value
                val data = Regex("""\d{2}/\d{2}/\d{4}""").find(textoBruto)?.value
                val valor = Regex("""R\$\s?\d{1,3}(\.\d{3})*[.,]\d{2}""").find(textoBruto)?.value
                val codDarf = Regex("""(0561|2089|6912|5952|1708)""").find(textoBruto)?.value
                val chaveNfe = Regex("""\d{44}""").find(textoBruto.replace(" ", ""))?.value

                // 2. Identifica o tipo do documento pelo conteúdo:
                val tipoDoc = when {
                    textoBruto.contains("DARF", ignoreCase = true) -> "Guia DARF"
                    textoBruto.contains("DANFE", ignoreCase = true) || chaveNfe != null -> "Nota Fiscal (NF-e)"
                    textoBruto.contains("FGTS", ignoreCase = true) || textoBruto.contains("eSocial", ignoreCase = true) -> "Guia Trabalhista"
                    else -> "Documento Fiscal"
                }

                val camposEncontrados = mutableListOf<String>()
                camposEncontrados.add("Tipo: $tipoDoc")
                if (cnpj != null) camposEncontrados.add("CNPJ: $cnpj")
                if (codDarf != null) camposEncontrados.add("Cód. Receita: $codDarf")
                if (data != null) camposEncontrados.add("Vencimento/Data: $data")
                if (valor != null) camposEncontrados.add("Valor: $valor")
                if (chaveNfe != null) camposEncontrados.add("Chave NF-e: ${chaveNfe.take(8)}...${chaveNfe.takeLast(4)}")

                val resumoEstruturado = if (camposEncontrados.size > 1) {
                    // Se achou dados fiscais (CNPJ, Valor, Data...), mostra SÓ os dados limpos!
                    "[IA ML Kit] " + camposEncontrados.joinToString(" | ")
                } else {
                    // Fallback: se fotografou um texto comum sem CNPJ/Valor, pega só os primeiros 120 caracteres
                    val trechoCurto = textoBruto.replace("\n", " ").trim().take(120)
                    "[IA ML Kit] Resumo: $trechoCurto..."
                }

                onResultado(resumoEstruturado)
            }
            .addOnFailureListener { erro ->
                onResultado("Falha na leitura OCR: ${erro.localizedMessage}")
            }
    }

    // Instancia as diferentes classes filhas dentro da mesma lista polimórfica
    fun itensIniciaisPolimorficos(): List<ItemAuditoria> = listOf(
        ItemTributoFederal(
            id = 1,
            codigoPapelTrabalho = "RFB-01",
            descricao = "Verificar guias de DARF pagas e conciliadas com DCTFWeb",
            codigoDarf = "0561"
        ),
        ItemTributoFederal(
            id = 2,
            codigoPapelTrabalho = "RFB-02",
            descricao = "Conferir apuração de IRPJ e CSLL no período",
            codigoDarf = "2089"
        ),
        ItemTributoFederal(
            id = 3,
            codigoPapelTrabalho = "RFB-03",
            descricao = "Validar recolhimento de PIS/COFINS (EFD-Contribuições)",
            codigoDarf = "6912"
        ),
        ItemTributoEstadual(
            id = 4,
            codigoPapelTrabalho = "SEFAZ-01",
            descricao = "Verificar escrituração de notas fiscais de ICMS",
            modeloDocumentoFiscal = "NF-e Modelo 55"
        ),
        ItemTributoEstadual(
            id = 5,
            codigoPapelTrabalho = "SEFAZ-02",
            descricao = "Conferir recolhimento de guias de ICMS-ST / DIFAL",
            modeloDocumentoFiscal = "GNRE Estadual"
        ),
        ItemTrabalhista(
            id = 6,
            codigoPapelTrabalho = "MTE-01",
            descricao = "Analisar folhas de pagamento e fechamento do eSocial",
            normaReferencia = "CLT Art. 464 / eSocial S-1200"
        ),
        ItemTrabalhista(
            id = 7,
            codigoPapelTrabalho = "MTE-02",
            descricao = "Verificar regularidade dos depósitos do FGTS Digital",
            normaReferencia = "Lei nº 8.036/90 (Art. 15)"
        )
    )

    companion object {
        private const val CHAVE_ITENS = "itens_polimorficos_v3"
        private const val CHAVE_PLANO = "plano_auditoria_v3"

        fun carregarMiniatura(caminho: String, amostra: Int): Bitmap? {
            val opcoes = BitmapFactory.Options().apply { inSampleSize = amostra }
            val bitmap = BitmapFactory.decodeFile(caminho, opcoes) ?: return null
            val graus = try {
                when (ExifInterface(caminho).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                    ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                    ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                    else -> 0f
                }
            } catch (e: Exception) {
                0f
            }
            if (graus == 0f) return bitmap
            val matriz = Matrix().apply { postRotate(graus) }
            return Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matriz, true)
        }

        fun miniaturaEmBytes(caminho: String): ByteArray {
            val bitmap = carregarMiniatura(caminho, 4) ?: return ByteArray(0)
            val saida = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, 80, saida)
            return saida.toByteArray()
        }
    }
}