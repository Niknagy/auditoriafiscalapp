package com.example.auditoriafiscal.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.navigation.NavController
import com.example.auditoriafiscal.R
import com.example.auditoriafiscal.model.ItemAuditoria
import com.example.auditoriafiscal.model.PlanoAuditoria
import com.example.auditoriafiscal.model.StatusApontamento
import com.example.auditoriafiscal.model.AuditoriaConcluida
import com.example.auditoriafiscal.viewmodel.AuditoriaUiState
import com.example.auditoriafiscal.viewmodel.AuditoriaViewModel
import kotlinx.serialization.Serializable
import java.io.File

// Rotas Tipadas da Navegacao
@Serializable object RotaHome
@Serializable object RotaCategorias
@Serializable data class RotaChecklist(val categoria: String)
@Serializable data class RotaResumo(val categoria: String)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TelaHome(navController: NavController, viewModel: AuditoriaViewModel) {
    val uiState by viewModel.uiState.collectAsState()
    val plano = uiState.plano
    val itens = uiState.itens

    var abaSelecionada by remember { mutableIntStateOf(0) }
    val titulosAbas = listOf("Geral", "Pendentes", "Falhas", "Conformes", "Histórico")

    var mostrarConfirmarNova by remember { mutableStateOf(false) }
    var mostrarDialogPlano by remember { mutableStateOf(false) }

    if (mostrarConfirmarNova) {
        AlertDialog(
            onDismissRequest = { mostrarConfirmarNova = false },
            title = { Text(text = "Nova Auditoria") },
            text = { Text(text = "Iniciar uma nova auditoria apagará o rascunho atual. Deseja continuar?") },
            confirmButton = {
                Button(onClick = {
                    mostrarConfirmarNova = false
                    viewModel.limparAuditoria()
                    mostrarDialogPlano = true
                }) { Text(text = "Confirmar") }
            },
            dismissButton = {
                TextButton(onClick = { mostrarConfirmarNova = false }) { Text(text = "Cancelar") }
            }
        )
    }

    if (mostrarDialogPlano) {
        DialogPlanoAuditoria(
            planoAtual = plano,
            onDismiss = { mostrarDialogPlano = false },
            onConfirm = { razao, cnpj, comp, resp ->
                viewModel.atualizarPlano(razao, cnpj, comp, resp)
                mostrarDialogPlano = false
                navController.navigate(RotaCategorias)
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text = "Gestão de Auditorias", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { mostrarConfirmarNova = true },
                containerColor = MaterialTheme.colorScheme.secondaryContainer,
                contentColor = MaterialTheme.colorScheme.onSecondaryContainer,
            ) {
                Text(text = "+ Nova Auditoria", fontWeight = FontWeight.Bold)
            }
        }
    ) { paddingValues ->
        Column(modifier = Modifier.padding(paddingValues).fillMaxSize()) {
            ScrollableTabRow(
                selectedTabIndex = abaSelecionada,
                edgePadding = 8.dp,
                containerColor = MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier.fillMaxWidth()
            ) {
                titulosAbas.forEachIndexed { index, titulo ->
                    Tab(
                        selected = abaSelecionada == index,
                        onClick = { abaSelecionada = index },
                        text = {
                            Text(
                                text = titulo,
                                fontWeight = if (abaSelecionada == index) FontWeight.Bold else FontWeight.Normal,
                                maxLines = 1
                            )
                        }
                    )
                }
            }

            when (abaSelecionada) {
                0 -> AbaJornadaAuditorUI(uiState, plano, viewModel, navController) { mostrarDialogPlano = true }
                1 -> ListaSomenteLeitura(itens.filter { it.status == "Pendente" }, "Tudo verificado!")
                2 -> ListaSomenteLeitura(itens.filter { it.status == "Não Conforme" }, "Nenhuma falha.")
                3 -> ListaSomenteLeitura(itens.filter { it.status == "Conforme" }, "Nenhum item conforme.")
                4 -> ListaHistoricoUI(uiState.historico)
            }
        }
    }
}

@Composable
fun AbaJornadaAuditorUI(
    uiState: AuditoriaUiState,
    plano: PlanoAuditoria,
    viewModel: AuditoriaViewModel,
    navController: NavController,
    onAbrirPlano: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Sua Jornada (ISO 19011)",
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.primary,
            fontWeight = FontWeight.Bold
        )

        ElevatedCard(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(text = "📍 Passo 1: Planejamento", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                Spacer(modifier = Modifier.height(12.dp))
                Text(text = plano.razaoSocial, fontWeight = FontWeight.Bold)
                Text(text = "CNPJ: ${plano.cnpj}", style = MaterialTheme.typography.bodyMedium)
                Text(text = "Protocolo: ${plano.protocolo}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                Spacer(modifier = Modifier.height(16.dp))
                OutlinedButton(onClick = onAbrirPlano, modifier = Modifier.fillMaxWidth()) {
                    Text(text = "📝 Editar Escopo")
                }
            }
        }

        ElevatedCard(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(text = "📋 Passo 2: Execução (Checklist)", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                Spacer(modifier = Modifier.height(12.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(text = "Pendentes: ${uiState.pendentes}", style = MaterialTheme.typography.bodyMedium)
                    Text(text = "Falhas: ${uiState.apontamentosAbertos}", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.error)
                }
                Spacer(modifier = Modifier.height(16.dp))
                Button(onClick = { navController.navigate(RotaCategorias) }, modifier = Modifier.fillMaxWidth()) {
                    Text(text = "📸 Abrir Checklist")
                }
            }
        }

        ElevatedCard(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(text = "☁️ Passo 3: Nuvem", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                Spacer(modifier = Modifier.height(12.dp))
                Text(text = uiState.statusNuvem, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.secondary)
                Spacer(modifier = Modifier.height(16.dp))
                FilledTonalButton(
                    onClick = { viewModel.sincronizarComNuvem() },
                    enabled = !uiState.sincronizandoNuvem,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(text = if (uiState.sincronizandoNuvem) "Enviando..." else "☁️ Enviar para Nuvem (D1/R2)")
                }
            }
        }
    }
}

@Composable
fun ListaHistoricoUI(historico: List<AuditoriaConcluida>) {
    LazyColumn(modifier = Modifier.padding(16.dp)) {
        if (historico.isEmpty()) {
            item { Text(text = "Nenhuma auditoria arquivada.", modifier = Modifier.padding(top = 16.dp)) }
        }
        items(historico) { arquivada ->
            ElevatedCard(
                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = "Protocolo: ${arquivada.plano.protocolo}", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelMedium)
                    Text(text = arquivada.plano.razaoSocial, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    Text(text = "Concluída em: ${arquivada.dataFechamento}", style = MaterialTheme.typography.bodySmall)
                    Text(text = "Itens auditados: ${arquivada.itens.size}", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

@Composable
fun DialogPlanoAuditoria(
    planoAtual: PlanoAuditoria,
    onDismiss: () -> Unit,
    onConfirm: (String, String, String, String) -> Unit
) {
    var razao by remember { mutableStateOf(planoAtual.razaoSocial) }
    var cnpj by remember { mutableStateOf(planoAtual.cnpj) }
    var competencia by remember { mutableStateOf(planoAtual.competenciaFiscal) }
    var responsavel by remember { mutableStateOf(planoAtual.responsavelAuditado) }

    val valido = razao.isNotBlank() && cnpj.isNotBlank() && competencia.isNotBlank() && responsavel.isNotBlank()

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(text = "Plano de Auditoria (ISO 19011)") },
        text = {
            Column {
                OutlinedTextField(value = razao, onValueChange = { razao = it }, label = { Text(text = "Razão Social Auditada") }, singleLine = true)
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(value = cnpj, onValueChange = { cnpj = it }, label = { Text(text = "CNPJ") }, singleLine = true)
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(value = competencia, onValueChange = { competencia = it }, label = { Text(text = "Período / Competência") }, singleLine = true)
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(value = responsavel, onValueChange = { responsavel = it }, label = { Text(text = "Responsável Local") }, singleLine = true)
            }
        },
        confirmButton = {
            Button(onClick = { onConfirm(razao, cnpj, competencia, responsavel) }, enabled = valido) {
                Text(text = "Salvar e Auditar")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(text = stringResource(R.string.btn_cancelar)) }
        }
    )
}

@Composable
fun ListaSomenteLeitura(itens: List<ItemAuditoria>, vazio: String) {
    LazyColumn(modifier = Modifier.padding(16.dp)) {
        if (itens.isEmpty()) {
            item { Text(text = vazio, modifier = Modifier.padding(top = 16.dp)) }
        }
        items(itens) { item ->
            CardItemSomenteLeitura(item)
            Spacer(modifier = Modifier.height(8.dp))
        }
    }
}

@Composable
fun TelaCategorias(navController: NavController) {
    val categorias = listOf("Tributos Federais", "Tributos Estaduais", "Trabalhista")

    Column(modifier = Modifier.padding(16.dp)) {
        TextButton(onClick = { navController.popBackStack() }) { Text(text = stringResource(R.string.btn_voltar)) }
        Spacer(modifier = Modifier.height(8.dp))
        Text(text = stringResource(R.string.iniciar_auditoria), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text(text = stringResource(R.string.selecione_categoria), style = MaterialTheme.typography.bodyLarge)
        Spacer(modifier = Modifier.height(24.dp))

        LazyColumn {
            items(categorias) { categoria ->
                Card(
                    onClick = { navController.navigate(RotaChecklist(categoria)) },
                    modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Text(text = categoria, modifier = Modifier.padding(24.dp), style = MaterialTheme.typography.titleMedium)
                }
            }
        }
    }
}

@Composable
fun TelaChecklistAuditoria(navController: NavController, categoria: String, viewModel: AuditoriaViewModel) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsState()
    val itensExibidos = uiState.itens.filter { it.categoria == categoria }
    var itemParaNaoConformidade by remember { mutableStateOf<ItemAuditoria?>(null) }

    var idItemFoto by rememberSaveable { mutableStateOf<Int?>(null) }
    var caminhoFotoPendente by rememberSaveable { mutableStateOf<String?>(null) }

    val cameraLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { sucesso ->
        val id = idItemFoto
        val caminho = caminhoFotoPendente
        if (id != null && caminho != null) {
            if (sucesso && File(caminho).length() > 0) {
                viewModel.registrarFoto(id, caminho)
            } else {
                viewModel.descartarArquivo(caminho)
            }
        }
        idItemFoto = null
        caminhoFotoPendente = null
    }

    Column(modifier = Modifier.padding(16.dp)) {
        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
            TextButton(onClick = { navController.popBackStack() }) { Text(text = stringResource(R.string.btn_voltar)) }
            Button(onClick = { navController.navigate(RotaResumo(categoria)) }) { Text(text = stringResource(R.string.btn_finalizar)) }
        }

        Spacer(modifier = Modifier.height(8.dp))
        Text(text = stringResource(R.string.titulo_checklist, categoria), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text(text = "Empresa: ${uiState.plano.razaoSocial} (${uiState.plano.competenciaFiscal})", style = MaterialTheme.typography.bodySmall)
        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn(modifier = Modifier.weight(1f)) {
            items(itensExibidos) { item ->
                CardItemAuditoria(
                    item = item,
                    onConformeClick = { viewModel.marcarConforme(item.id) },
                    onEvidenciaClick = {
                        val arquivo = viewModel.novoArquivoFoto(item.id)
                        idItemFoto = item.id
                        caminhoFotoPendente = arquivo.absolutePath
                        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", arquivo)
                        cameraLauncher.launch(uri)
                    },
                    onNaoConformeClick = { itemParaNaoConformidade = item },
                    onRemoverEvidenciaClick = { viewModel.removerFoto(item.id) }
                )
                Spacer(modifier = Modifier.height(12.dp))
            }
        }
    }

    itemParaNaoConformidade?.let { item ->
        DialogNaoConformidade(
            item = item,
            onDismiss = { itemParaNaoConformidade = null },
            onLerFotoIA = { retornarTexto ->
                item.caminhoFoto?.let { caminho ->
                    viewModel.extrairDadosDaFotoComIA(caminho, retornarTexto)
                }
            },
            onSave = { severidade, criterio, observacao, prazo ->
                viewModel.registrarNaoConformidade(item.id, severidade, criterio, observacao, prazo)
                itemParaNaoConformidade = null
            }
        )
    }
}

@Composable
fun TelaResumoAuditoria(navController: NavController, categoria: String, viewModel: AuditoriaViewModel) {
    val uiState by viewModel.uiState.collectAsState()
    val plano = uiState.plano
    val itensAuditados = uiState.itens.filter { it.categoria == categoria }
    val pendentes = itensAuditados.count { it.status == "Pendente" }
    val conformes = itensAuditados.count { it.status == "Conforme" }
    val naoConformes = itensAuditados.count { it.status == "Não Conforme" }

    val apontamentos = itensAuditados.filter { it.naoConformidade != null }
    val apPendentes = apontamentos.count { it.naoConformidade!!.obterStatus() == StatusApontamento.PENDENTE }
    val apAndamento = apontamentos.count { it.naoConformidade!!.obterStatus() == StatusApontamento.EM_ANDAMENTO }
    val apResolvidos = apontamentos.count { it.naoConformidade!!.obterStatus() == StatusApontamento.RESOLVIDO }

    Column(modifier = Modifier.padding(16.dp).fillMaxSize()) {
        Text(text = stringResource(R.string.resumo_auditoria), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text(text = "${plano.protocolo} - ${plano.razaoSocial} (CNPJ: ${plano.cnpj})", style = MaterialTheme.typography.bodySmall) // <-- CORRIGIDO!
        Spacer(modifier = Modifier.height(12.dp))

        Card(modifier = Modifier.fillMaxWidth(), elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(text = stringResource(R.string.resultados_consolidados), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))
                Text(text = stringResource(R.string.qtd_conformes, conformes), color = MaterialTheme.colorScheme.primary)
                Text(text = stringResource(R.string.qtd_nao_conformes, naoConformes), color = MaterialTheme.colorScheme.error)
                Text(text = stringResource(R.string.qtd_pendentes, pendentes), color = MaterialTheme.colorScheme.secondary)

                Spacer(modifier = Modifier.height(12.dp))
                Text(text = stringResource(R.string.apontamentos_titulo), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))
                Text(text = stringResource(R.string.qtd_ap_pendentes, apPendentes))
                Text(text = stringResource(R.string.qtd_ap_andamento, apAndamento))
                Text(text = stringResource(R.string.qtd_ap_resolvidos, apResolvidos))
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
        Text(text = stringResource(R.string.detalhamento_itens), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(8.dp))

        LazyColumn(modifier = Modifier.weight(1f)) {
            items(itensAuditados) { item ->
                Card(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp), elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(text = "[${item.codigoPapelTrabalho}] ${item.descricao}", fontWeight = FontWeight.Bold)
                        val nc = item.naoConformidade
                        if (item.status == "Não Conforme" && nc != null) {
                            Text(text = stringResource(R.string.status_nao_conforme, nc.nivelSeveridade), color = MaterialTheme.colorScheme.error)
                            Text(text = "Critério Legal: ${nc.criterioNormativo}", style = MaterialTheme.typography.bodySmall)
                            Text(text = stringResource(R.string.obs_nao_conformidade, nc.observacao), style = MaterialTheme.typography.bodySmall)
                            Text(text = stringResource(R.string.prazo_nao_conformidade, nc.prazoResolucao), style = MaterialTheme.typography.bodySmall)
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                StatusApontamento.todos.forEach { status ->
                                    FilterChip(
                                        selected = nc.obterStatus() == status,
                                        onClick = { viewModel.atualizarStatusApontamento(item.id, status) },
                                        label = { Text(text = status, style = MaterialTheme.typography.labelSmall) }
                                    )
                                }
                            }
                        } else if (item.status == "Conforme") {
                            Text(text = stringResource(R.string.status_conforme), color = MaterialTheme.colorScheme.primary)
                        } else {
                            Text(text = stringResource(R.string.status_pendente), color = MaterialTheme.colorScheme.secondary)
                        }
                        item.caminhoFoto?.let { MiniaturaEvidencia(it, item.timestampFoto) }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Button(
            onClick = {
                viewModel.fecharEArquivarAuditoria() // Dispara a criação do Histórico!
                navController.popBackStack<RotaHome>(inclusive = false)
            },
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
            modifier = Modifier.fillMaxWidth().height(55.dp)
        ) {
            Text(text = "🔒 Fechar Auditoria e Arquivar no Histórico", fontWeight = FontWeight.Bold)
        }
    }
}